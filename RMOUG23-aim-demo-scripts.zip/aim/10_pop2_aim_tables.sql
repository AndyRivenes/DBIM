@../aim_login.sql

set pages 9999
set lines 150
set echo on

select count(*) from lrgtab4;
select count(*) from lrgtab4;
select count(*) from lrgtab4;
select count(*) from lrgtab4;

set echo off

