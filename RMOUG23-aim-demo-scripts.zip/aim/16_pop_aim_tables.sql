@../aim_login.sql

set pages 999
set lines 200
set echo on

select count(*) from lrgtab3;
select count(*) from lrgtab3;
select count(*) from lrgtab3;
select count(*) from lrgtab3;
select count(*) from lrgtab3;
select count(*) from lrgtab3;

set echo off

