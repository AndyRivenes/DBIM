@../aim_login.sql

set pages 9999
set lines 150
set echo on

select count(*) from lrgtab1;
select count(*) from lrgtab1;

select count(*) from lrgtab2;
select count(*) from lrgtab2;
select count(*) from lrgtab2;

select count(*) from lrgtab3;
select count(*) from medtab1;
select count(*) from medtab1;
select count(*) from medtab1;
select count(*) from medtab2;
select count(*) from medtab2;
select count(*) from medtab2;

set echo off

