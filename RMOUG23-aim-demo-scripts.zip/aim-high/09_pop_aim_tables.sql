@../aim_login.sql

set pages 999
set lines 200
set echo on

select count(*) from lrgtab1;
select count(*) from lrgtab1;

select count(*) from lrgtab2;
select count(*) from lrgtab2;
select count(*) from lrgtab2;

select count(*) from lrgtab3;
select count(*) from medtab1;
select count(*) from medtab1;
select count(*) from medtab1;
select count(*) from medtab2;
select count(*) from medtab2;
select count(*) from medtab2;

select count(*) from lrgtab4;
select count(*) from lrgtab4;

set echo off

